﻿namespace _07RawData
{
    enum CargoTypeEnum
    {
        fragile,
        flamable
    }
}
